INSERT INTO ITEM (ID,name,price,quantity) VALUES
(1,'Beer',1.5,1000);
INSERT INTO ITEM (ID,name,price,quantity) VALUES
(2,'Peanuts',0.5,1000);
INSERT INTO ITEM (ID,name,price,quantity) VALUES
(3,'Cookies',2.2,500);


INSERT INTO EMPLOYEE (ID,name,password) VALUES
(1,'Yee Emplo','one');


INSERT INTO CUSTOMER (ID,name) VALUES
(1,'John Doe');
INSERT INTO CUSTOMER (ID,name) VALUES
(2,'Jane Doe');
