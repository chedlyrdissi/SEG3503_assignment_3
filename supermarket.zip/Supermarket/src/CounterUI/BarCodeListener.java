
package CounterUI;

public interface BarCodeListener {
  void readValue(BarCodeReaderEvent event);
}